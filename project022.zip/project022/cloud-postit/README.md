npm install express mongoose cors dotenv bcrypt jsonwebtoken multer swagger-ui-express swagger-jsdoc
npm install --save-dev nodemon jest supertest